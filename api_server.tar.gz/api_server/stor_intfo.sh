torify curl http://ipinfo.io; echo
