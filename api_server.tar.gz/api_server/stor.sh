tor -f /etc/tor/torrc &
