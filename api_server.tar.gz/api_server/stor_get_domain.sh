cat /var/lib/tor/hidden_service/hostname
