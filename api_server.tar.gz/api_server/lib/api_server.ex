defmodule ApiServer do
  @moduledoc """
  Documentation for `ApiServer`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> ApiServer.hello()
      :world

  """
  def hello do
    :world
  end
end
