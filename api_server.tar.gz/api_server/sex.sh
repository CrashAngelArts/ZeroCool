iex -S  mix
